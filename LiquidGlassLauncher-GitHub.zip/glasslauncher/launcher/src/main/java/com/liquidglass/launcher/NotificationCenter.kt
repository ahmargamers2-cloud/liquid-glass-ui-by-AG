package com.liquidglass.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.provider.Settings
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Liquid-glass Notification Center (launcher ke andar). */
class NotificationCenterView(ctx: Context, private val host: Host) : Overlay(ctx), NotificationHub.Listener {

    private val title = TextView(ctx).apply {
        text = "Notifications"
        setTextColor(Color.WHITE)
        textSize = 30f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setShadowLayer(8f, 0f, 2f, 0x55000000)
    }
    private val clear = TextView(ctx).apply {
        text = "Clear all"
        setTextColor(Color.WHITE)
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(ctx.dpi(14f), ctx.dpi(8f), ctx.dpi(14f), ctx.dpi(8f))
        setBackgroundColor(0x00000000)
    }
    private val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val sv = ScrollView(ctx).apply {
        isVerticalScrollBarEnabled = false
        clipToPadding = false
        overScrollMode = OVER_SCROLL_NEVER
    }
    private val header = FrameLayout(ctx)

    init {
        val pad = ctx.dpi(18f)
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        header.addView(title, LayoutParams(WRAP, WRAP, Gravity.CENTER_VERTICAL or Gravity.START))
        header.addView(clear, LayoutParams(WRAP, WRAP, Gravity.CENTER_VERTICAL or Gravity.END))
        col.addView(header, LinearLayout.LayoutParams(MATCH, ctx.dpi(56f)).apply {
            leftMargin = pad
            rightMargin = pad
        })
        col.addView(list, LinearLayout.LayoutParams(MATCH, WRAP).apply {
            leftMargin = pad
            rightMargin = pad
        })
        sv.addView(col, LayoutParams(MATCH, WRAP))
        addView(sv, LayoutParams(MATCH, MATCH))
        clear.setOnClickListener { NotificationHub.cancelAll() }
        sv.setOnClickListener { close() }
    }

    fun setInsets(top: Int, bottom: Int) {
        sv.setPadding(0, top + dpi(16f), 0, bottom + dpi(24f))
    }

    override fun onOpen() {
        sv.scrollTo(0, 0)
        rebuild()
    }

    override fun onNotificationsChanged() {
        if (isOpen) rebuild()
    }

    override fun onNotificationPosted(item: NotificationHub.Item) {}

    private fun rebuild() {
        list.removeAllViews()
        if (!NotificationHub.isAccessEnabled(context)) {
            clear.visibility = View.GONE
            list.addView(infoCard("Notification access chalu karo", "Taaki yahan glass style me notifications dikhein.", "Allow") {
                host.closeOverlays()
                host.startSafe(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            })
            return
        }
        val items = NotificationHub.items(context)
        clear.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        if (items.isEmpty()) {
            list.addView(TextView(context).apply {
                text = "No new notifications"
                setTextColor(0xCCFFFFFF.toInt())
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(0, dpi(80f), 0, 0)
            }, LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }
        val max = 7
        for (it in items.take(max)) list.addView(card(it), cardParams())
        if (items.size > max) {
            list.addView(TextView(context).apply {
                text = "+" + (items.size - max) + " more"
                setTextColor(0xB3FFFFFF.toInt())
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, dpi(6f), 0, dpi(6f))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    private fun cardParams() = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dpi(10f) }

    private fun infoCard(head: String, body: String, button: String, onClick: () -> Unit): View {
        val g = glassPanel(context, host.backdrop, 24f, tint = 0x30FFFFFF, blur = 0.1f)
        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpi(18f), dpi(16f), dpi(18f), dpi(16f))
        }
        col.addView(TextView(context).apply {
            text = head
            setTextColor(Color.WHITE)
            textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        })
        col.addView(TextView(context).apply {
            text = body
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 14f
            setPadding(0, dpi(4f), 0, dpi(10f))
        })
        col.addView(TextView(context).apply {
            text = button
            setTextColor(0xFF0A84FF.toInt())
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setOnClickListener { onClick() }
            setPadding(0, dpi(4f), dpi(16f), dpi(4f))
        })
        g.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        return g
    }

    private fun card(n: NotificationHub.Item): View {
        val g = glassPanel(context, host.backdrop, 24f, tint = 0x30FFFFFF, blur = 0.1f)
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dpi(14f), dpi(12f), dpi(8f), dpi(12f))
        }
        val icon = ImageView(context).apply {
            setImageDrawable(n.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        row.addView(icon, LinearLayout.LayoutParams(dpi(36f), dpi(36f)).apply { rightMargin = dpi(12f) })

        val texts = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(TextView(context).apply {
            text = n.appName
            setTextColor(0xB3FFFFFF.toInt())
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        top.addView(TextView(context).apply {
            text = DateUtils.getRelativeTimeSpanString(n.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
            setTextColor(0x99FFFFFF.toInt())
            textSize = 12f
        })
        texts.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        if (n.title.isNotEmpty()) {
            texts.addView(TextView(context).apply {
                text = n.title
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        if (n.text.isNotEmpty()) {
            texts.addView(TextView(context).apply {
                text = n.text
                setTextColor(0xE6FFFFFF.toInt())
                textSize = 14f
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f))

        val close = TextView(context).apply {
            text = "\u00D7"
            setTextColor(0xCCFFFFFF.toInt())
            textSize = 24f
            gravity = Gravity.CENTER
            setOnClickListener { NotificationHub.cancel(n.key) }
        }
        row.addView(close, LinearLayout.LayoutParams(dpi(36f), dpi(36f)))

        g.addView(row, FrameLayout.LayoutParams(MATCH, WRAP))
        g.setOnClickListener {
            host.closeOverlays()
            try {
                n.intent?.send()
            } catch (e: Exception) {
                host.toast("Open nahi ho paaya")
            }
            if (n.clearable) NotificationHub.cancel(n.key)
        }
        return g
    }
}

/** Naya notification aane pe upar glass banner. */
class BannerView(ctx: Context, private val host: Host) : FrameLayout(ctx) {

    private val glass = glassPanel(ctx, host.backdrop, 26f, tint = 0x38FFFFFF, blur = 0.12f)
    private val icon = ImageView(ctx)
    private val head = TextView(ctx).apply {
        setTextColor(Color.WHITE)
        textSize = 15f
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }
    private val body = TextView(ctx).apply {
        setTextColor(0xE6FFFFFF.toInt())
        textSize = 14f
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
    }
    private val hide = Runnable { dismiss() }
    private var current: NotificationHub.Item? = null

    init {
        visibility = GONE
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(ctx.dpi(14f), ctx.dpi(12f), ctx.dpi(14f), ctx.dpi(12f))
        }
        row.addView(icon, LinearLayout.LayoutParams(ctx.dpi(38f), ctx.dpi(38f)).apply { rightMargin = ctx.dpi(12f) })
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(body, LinearLayout.LayoutParams(MATCH, WRAP))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
        glass.addView(row, LayoutParams(MATCH, WRAP))
        addView(glass, LayoutParams(MATCH, WRAP))
        glass.setOnClickListener {
            val n = current
            dismiss()
            if (n != null) {
                host.closeOverlays()
                try {
                    n.intent?.send()
                } catch (e: Exception) {
                }
            }
        }
    }

    fun show(n: NotificationHub.Item) {
        current = n
        icon.setImageDrawable(n.icon)
        head.text = if (n.title.isNotEmpty()) n.title else n.appName
        body.text = n.text
        removeCallbacks(hide)
        animate().cancel()
        visibility = VISIBLE
        translationY = -dp(140f)
        alpha = 1f
        animate().translationY(0f).setDuration(260).start()
        postDelayed(hide, 4500)
    }

    fun dismiss() {
        removeCallbacks(hide)
        animate().cancel()
        animate().translationY(-dp(160f)).setDuration(220).withEndAction { visibility = GONE }.start()
    }
}
