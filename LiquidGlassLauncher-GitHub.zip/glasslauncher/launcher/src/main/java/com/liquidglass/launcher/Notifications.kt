package com.liquidglass.launcher

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Notification access milne ke baad system ke notifications yahan aate hain,
 * jinhe launcher apne liquid-glass Notification Center me dikhata hai.
 */
object NotificationHub {

    class Item(
        val key: String,
        val pkg: String,
        val appName: String,
        val title: String,
        val text: String,
        val time: Long,
        val icon: Drawable?,
        val intent: PendingIntent?,
        val clearable: Boolean
    )

    interface Listener {
        fun onNotificationsChanged()
        fun onNotificationPosted(item: Item)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var service: GlassNotificationService? = null

    fun addListener(l: Listener) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    fun isAccessEnabled(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun items(ctx: Context): List<Item> {
        val s = service ?: return emptyList()
        val arr: Array<StatusBarNotification> = try {
            s.activeNotifications ?: return emptyList()
        } catch (e: Exception) {
            return emptyList()
        }
        val out = ArrayList<Item>()
        for (sbn in arr) {
            toItem(ctx, sbn)?.let { out.add(it) }
        }
        out.sortByDescending { it.time }
        return out
    }

    fun counts(ctx: Context): Map<String, Int> {
        val map = HashMap<String, Int>()
        for (i in items(ctx)) map[i.pkg] = (map[i.pkg] ?: 0) + 1
        return map
    }

    fun cancel(key: String) {
        try {
            service?.cancelNotification(key)
        } catch (e: Exception) {
        }
        notifyChanged()
    }

    fun cancelAll() {
        try {
            service?.cancelAllNotifications()
        } catch (e: Exception) {
        }
        notifyChanged()
    }

    fun notifyChanged() {
        main.post { for (l in listeners) l.onNotificationsChanged() }
    }

    internal fun onPosted(ctx: Context, sbn: StatusBarNotification) {
        val item = toItem(ctx, sbn)
        main.post {
            for (l in listeners) {
                l.onNotificationsChanged()
                if (item != null) l.onNotificationPosted(item)
            }
        }
    }

    private fun toItem(ctx: Context, sbn: StatusBarNotification): Item? {
        val n = sbn.notification ?: return null
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return null
        if (sbn.packageName == ctx.packageName) return null
        if (sbn.isOngoing) return null
        val ex = n.extras
        val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex?.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex?.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isEmpty() && text.isEmpty()) return null
        val pm = ctx.packageManager
        var appName = sbn.packageName
        var icon: Drawable? = null
        try {
            val ai = pm.getApplicationInfo(sbn.packageName, 0)
            appName = pm.getApplicationLabel(ai).toString()
            icon = pm.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
        }
        return Item(
            key = sbn.key,
            pkg = sbn.packageName,
            appName = appName,
            title = title,
            text = text,
            time = if (sbn.postTime > 0) sbn.postTime else System.currentTimeMillis(),
            icon = icon,
            intent = n.contentIntent,
            clearable = sbn.isClearable
        )
    }
}

class GlassNotificationService : NotificationListenerService() {

    override fun onListenerConnected() {
        NotificationHub.service = this
        NotificationHub.notifyChanged()
    }

    override fun onListenerDisconnected() {
        NotificationHub.service = null
        NotificationHub.notifyChanged()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) NotificationHub.onPosted(applicationContext, sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        NotificationHub.notifyChanged()
    }
}
