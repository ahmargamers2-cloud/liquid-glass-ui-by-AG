package com.liquidglass.launcher

import android.content.Context
import android.view.View
import android.view.ViewGroup
import com.example.liquidglass.LiquidGlassView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Float): Float = context.dp(v)
fun View.dpi(v: Float): Int = context.dpi(v)

/**
 * Ek liquid glass panel banata hai. Glass ke peeche ka content `backdrop` view se capture hota hai
 * (backdrop view glass ka parent/ancestor nahi hona chahiye, sibling ho).
 */
fun glassPanel(
    ctx: Context,
    backdrop: View?,
    radiusDp: Float,
    tint: Int = 0x26FFFFFF,
    blur: Float = 0.08f
): LiquidGlassView {
    return LiquidGlassView(ctx).apply {
        cornerRadius = ctx.dp(radiusDp)
        backdropSource = backdrop
        enableDynamicBackground = true
        enablePressEffect = false
        blurAmount = blur
        saturation = 150f
        glassTint = tint
        collectFrameStats = false
    }
}
