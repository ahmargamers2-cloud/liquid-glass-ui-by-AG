# Liquid Glass Launcher

An Android launcher project with a Liquid Glass-inspired interface.

## Build an APK without Android Studio (GitHub Actions)

You do **not** need Android Studio or a computer with the Android SDK. GitHub Actions can compile the project in the cloud.

### 1. Create a GitHub repository

1. Sign in at [GitHub](https://github.com/).
2. Select **New repository**.
3. Name it `LiquidGlassLauncher` (or any name you prefer).
4. Choose **Public** or **Private**, then create the repository.

### 2. Upload this project

1. Extract the downloaded project ZIP on your computer.
2. Open your new empty GitHub repository.
3. Select **Add file → Upload files**.
4. Upload the *contents* of the extracted `glasslauncher` folder. Make sure `.github/workflows/build-launcher.yml`, `gradlew`, `gradle/`, `launcher/`, `liquidglass/`, `app/`, and the Gradle files are included.
5. Commit the upload to the `main` branch.

> Important: GitHub must see `.github/workflows/build-launcher.yml` at the repository root. Do not upload the whole project as one ZIP file; GitHub will not unpack it for Actions.

### 3. Start / find the build

The workflow starts automatically after you commit to `main` or `master`.

To start it manually:

1. Open the repository's **Actions** tab.
2. Select **Build Liquid Glass Launcher**.
3. Press **Run workflow → Run workflow**.

Wait for the run to finish. A green check means the build completed. If it fails, open the run and expand the failed step to see the error log.

### 4. Download the APK

1. Open the completed workflow run in **Actions**.
2. Scroll to **Artifacts** at the bottom.
3. Download `liquid-glass-launcher-debug`.
4. Extract the downloaded artifact ZIP. It contains the debug APK.
5. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

The workflow builds the `:launcher` module, not the demo `:app` module.

## Build locally from a terminal (optional)

If you later use a computer with Java 17, Android SDK, NDK `27.0.12077973`, and CMake `3.22.1` installed:

```bash
./gradlew :launcher:assembleDebug
```

The APK is created at:

```text
launcher/build/outputs/apk/debug/launcher-debug.apk
```

On Windows PowerShell use:

```powershell
.\gradlew.bat :launcher:assembleDebug
```

## Android compatibility

The launcher module sets `minSdk = 26` (Android 8.0 Oreo). Some advanced glass rendering effects may use a simpler fallback on older Android versions.

## Build notes

- GitHub Actions uses Java 17, Android SDK 36, NDK 27.0.12077973, and CMake 3.22.1.
- The workflow produces a **debug-signed APK** suitable for testing. It is not a Play Store release build.
- No signing key or passwords are needed for this debug build. Never commit a private release keystore or its passwords to GitHub.
- The first build can take several minutes while Gradle and Android dependencies are downloaded.
