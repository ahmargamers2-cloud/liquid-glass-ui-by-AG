# Liquid Glass Launcher update

This update is a source-level improvement pass for the `:launcher` module.

## Changes
- Raised the launcher minimum Android version to API 26 (Android 8.0 Oreo), matching the requested minimum.
- Added a restrained depth/scale/fade page transition to the home-screen pager.
- Disabled RecyclerView's default item animator inside ViewPager2 to avoid competing animations during page rebuilds.
- Smoothed overlay open/close transitions with coordinated scale + alpha easing.
- Refined app-icon and Control Center button press/release feedback, including a soft overshoot on release.
- Slider touch handling now releases parent touch interception when the gesture ends or is cancelled.

## Build
From Android Studio, open this project and run `:launcher:assembleDebug`.
The command-line build could not be completed in the editing environment because Gradle 8.11.1 was not cached and `services.gradle.org` was unreachable. No successful APK build is claimed.

## Important scope note
The existing source already includes the glass icon renderer, home pages, dock, app library, basic clock widget, Control Center overlay, notification center, wallpaper picker, and app context menus. This update does not yet add a full AppWidgetHost-based third-party widget system or drag-and-drop icon rearrangement; those require a separate implementation and on-device validation.
